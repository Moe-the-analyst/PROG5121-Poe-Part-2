// ChatApp.java
// Student-style commented version for submission.

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ChatApp {
    private static Scanner scanner = new Scanner(System.in);
    private static ArrayList<Message> messages = new ArrayList<>();

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome To QuickChat");

        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");

        if (username != null && password != null && !username.isEmpty() && !password.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Login Successful! Welcome, " + username);
            runMenu();
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Please restart the program.");
        }
    }

    // ---------------- MENU ----------------
    public static void runMenu() {
        int numMessages = Integer.parseInt(JOptionPane.showInputDialog("Enter how many messages you want to send:"));
        int sentCount = 0;

        while (true) {
            String menu = "Select an option:\n1) Send Message\n2) Show Recently Sent Messages\n3) Quit";
            int choice = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (choice) {
                case 1:
                    if (sentCount < numMessages) {
                        Message message = new Message();
                        message.sendMessage();
                        messages.add(message);
                        sentCount++;
                    } else {
                        JOptionPane.showMessageDialog(null, "You have reached your message limit.");
                    }
                    break;

                case 2:
                    JOptionPane.showMessageDialog(null, "Coming soon");
                    break;

                case 3:
                    JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.returnTotalMessages());
                    saveMessagesToJSON();
                    System.exit(0);
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }

    // ---------------- SAVE TO JSON ----------------
    public static void saveMessagesToJSON() {
        JSONArray jsonMessages = new JSONArray();

        for (Message m : messages) {
            JSONObject msgObj = new JSONObject();
            msgObj.put("MessageID", m.getMessageID());
            msgObj.put("MessageHash", m.getMessageHash());
            msgObj.put("Recipient", m.getRecipient());
            msgObj.put("Message", m.getMessage());
            jsonMessages.add(msgObj);
        }

        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(jsonMessages.toJSONString());
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages.");
        }
    }
}
