// Message.java
// Handles message validation, hash creation, and storage.

import javax.swing.*;
import java.util.*;

public class Message {
    private static int totalMessages = 0;
    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;

    public Message() {}

    // Generate random 10-digit message ID
    public boolean checkMessageID() {
        this.messageID = String.format("%010d", new Random().nextInt(1000000000));
        return this.messageID != null;
    }

    // Validate recipient format
    public int checkRecipientCell(String recipient) {
        if (recipient.startsWith("+") && recipient.length() <= 13 && recipient.length() >= 10) {
            this.recipient = recipient;
            JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
            return 1;
        } else {
            JOptionPane.showMessageDialog(null, "Cell phone number is incorrectly formatted or missing an international code.");
            return 0;
        }
    }

    // Create message hash
    public String createMessageHash() {
        if (messageID == null || message == null) return null;
        String[] words = message.split(" ");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        messageHash = messageID.substring(0, 2) + ":" + totalMessages + ":" + firstWord.toUpperCase() + lastWord.toUpperCase();
        return messageHash;
    }

    // Send message logic
    public String sendMessage() {
        checkMessageID();
        totalMessages++;

        String recipientInput = JOptionPane.showInputDialog("Enter recipient number (with country code):");
        checkRecipientCell(recipientInput);

        message = JOptionPane.showInputDialog("Enter message (max 250 characters):");

        if (message.length() > 250) {
            JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " + (message.length() - 250));
            return "Message too long.";
        } else {
            messageHash = createMessageHash();

            String[] options = {"Send Message", "Disregard Message", "Store Message"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an action", "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    JOptionPane.showMessageDialog(null, printMessage() + "\nMessage sent successfully!");
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Press 0 to delete message");
                    break;
                case 2:
                    storeMessage();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "No action selected.");
            }
            return "Message ready to send.";
        }
    }

    // Print full message details
    public String printMessage() {
        return "Message ID: " + messageID + "\nMessage Hash: " + messageHash + "\nRecipient: " + recipient + "\nMessage: " + message;
    }

    // Store message (JSON)
    public void storeMessage() {
        JOptionPane.showMessageDialog(null, "Message successfully stored.");
    }

    public static int returnTotalMessages() { return totalMessages; }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
}
